#!/bin/sh

# Приветствие при запуске скрипта
echo "Скрипт начал выполнение."

# Исходная строка
str="Сидельников Артем Максимович, 04.06.2003, г. Санкт-Петербург, Школа 18, Дизайнер графических и пользовательских интерфейсов"
echo "Исходная строка:"
echo $str

# Создание временного файла с 500 повторениями исходной строки
echo "Создание временного файла..."
for i in $(seq 1 500);
do
    echo $str
done > temp_b.txt
echo "Временный файл создан."

# Создание входного файла с 1000 повторениями содержимого временного файла
echo "Создание входного файла..."
for q in $(seq 1 1000);
do
    cat "temp_b.txt"
done > input_b.txt
echo "Входной файл создан."

# Удаление временного файла
echo "Удаление временного файла..."
rm temp_b.txt
echo "Файл удален."

# Конвертация входного файла в кодировки CP866 и CP1251
echo "Конвертация входного файла в кодировки CP866 и CP1251..."
iconv -t CP866 -o b_input_866.txt input_b.txt
iconv -t CP1251 -o b_input_1251.txt input_b.txt
echo "Конвертация завершена."

# Перевод в UPPERCASE
echo "Перевод в UPPERCASE..."
upperRegex='s/а/А/g;s/б/Б/g;s/в/В/g;s/г/Г/g;s/д/Д/g;s/е/Е/g;s/ё/Ё/g;s/ж/Ж/g;s/з/З/g;s/и/И/g;s/й/Й/g;s/к/К/g;s/л/Л/g;s/м/М/g;s/н/Н/g;s/о/О/g;s/п/П/g;s/р/Р/g;s/с/С/g;s/т/Т/g;s/у/У/g;s/ф/Ф/g;s/х/Х/g;s/ц/Ц/g;s/ч/Ч/g;s/ш/Ш/g;s/щ/Щ/g;s/ъ/Ъ/g;s/ы/Ы/g;s/ь/Ь/g;s/э/Э/g;s/ю/Ю/g;s/я/Я/g'
upper_866=$(echo "$upperRegex" | iconv -t CP866)
upper_1251=$(echo "$upperRegex" | iconv -t CP1251)

eval "cat b_input_866.txt | sed \"$upper_866\"" > b_input_upper_866.txt
eval "cat b_input_1251.txt | sed \"$upper_1251\"" > b_input_upper_1251.txt
echo "Перевод в UPPERCASE завершен."

# Удаление файлов с кодировками CP866 и CP1251
echo "Удаление промежуточных файлов..."
rm b_input_866.txt b_input_1251.txt
echo "Промежуточные файлы удалены."

# Смена кодировок
echo "Смена кодировок..."
iconv -f CP866 -t CP1251 -o b_output_1251.txt b_input_upper_866.txt
iconv -f CP1251 -t CP866 -o b_output_866.txt b_input_upper_1251.txt
echo "Смена кодировок завершена."

# Транслитерация
echo "Транслитерация..."
transpileRegex='s/А/A/g;s/В/B/g;s/С/C/g;s/Е/E/g;s/Н/H/g;s/К/K/g;s/М/M/g;s/О/O/g;s/Р/P/g;s/Т/T/g;s/Х/X/g;s/У/Y/g;'
transpile_866=$(echo "$transpileRegex" | iconv -t CP866)
transpile_1251=$(echo "$transpileRegex" | iconv -t CP1251)

eval "cat b_output_866.txt | sed \"$transpile_866\"" > final_output_cp866.txt
eval "cat b_output_1251.txt | sed \"$transpile_1251\"" > final_output_cp1251.txt
echo "Транслитерация завершена."

# Удаление промежуточных файлов
echo "Удаление промежуточных файлов..."
rm b_input_upper_866.txt b_input_upper_1251.txt b_output_866.txt b_output_1251.txt
echo "Промежуточные файлы удалены."

# Создание архива с итоговыми файлами
echo "Создание архива с итоговыми файлами..."
zip final_b_output.zip final_output_cp866.txt final_output_cp1251.txt
echo "Архивы созданы."

# Удаление итоговых файлов
echo "Удаление итоговых файлов..."
rm final_output_cp866.txt final_output_cp1251.txt input_b.txt
echo "Итоговые файлы удалены."

# Сообщение об окончании выполнения скрипта
echo "Скрипт успешно завершил выполнение."
