#!/bin/bash

# Определение строки и кодировок
string="Сидельников Артем Максимович, 04.06.2003, город: Санкт-Петербург, профессия:Веб-разработчик "
encodings=("UTF-8" "CP866" "Windows-1251" "KOI8")

# Предварительное выделение памяти
n=100000
a=()
b=()
c=()

# Заполнение массивов
for i in $(seq 1 $n); do
    a[i]=$(echo $string | iconv -f UTF-8 -t ${encodings[0]})
    b[i]=$(echo $string | iconv -f UTF-8 -t ${encodings[1]})
    c[i]=$(echo $string | iconv -f UTF-8 -t ${encodings[2]})
done

# Запись результатов в файл
for i in $(seq 1 $n); do
    echo "${a[i]} ${b[i]} ${c[i]}" >> result.txt
done
